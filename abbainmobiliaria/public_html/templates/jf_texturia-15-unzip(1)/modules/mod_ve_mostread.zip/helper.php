<?php
/*------------------------------------------------------------------------
# mod_ve_mostread - Most Read Content 2
# ------------------------------------------------------------------------
# author    Vsmart Extensions
# copyright Copyright (C) 2010 www.vsmart-extensions.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://www.vsmart-extensions.com
# Technical Support:  Forum - http://www.vsmart-extensions.com
-------------------------------------------------------------------------*/

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once (JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');

class modVEMostReadHelper
{
	function getList(&$params)
	{
		global $mainframe;

		$db			=& JFactory::getDBO();
		$user		=& JFactory::getUser();

		$count		= intval($params->get('count', 5));
		$catid		= trim($params->get('catid'));
		$secid		= trim($params->get('secid'));
		$show_front	= $params->get('show_front', 1);
		$aid		= $user->get('aid', 0);

		$contentConfig = &JComponentHelper::getParams( 'com_content' );
		$access		= !$contentConfig->get('show_noauth');

		$nullDate	= $db->getNullDate();
		$date =& JFactory::getDate();
		$now  = $date->toMySQL();

		if ($catid) {
			$ids = explode( ',', $catid );
			JArrayHelper::toInteger( $ids );
			$catCondition = ' AND (cc.id=' . implode( ' OR cc.id=', $ids ) . ')';
		}
		if ($secid) {
			$ids = explode( ',', $secid );
			JArrayHelper::toInteger( $ids );
			$secCondition = ' AND (s.id=' . implode( ' OR s.id=', $ids ) . ')';
		}

		//Content Items only
		$query = 'SELECT a.*,' .
			' CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(":", a.id, a.alias) ELSE a.id END as slug,'.
			' CASE WHEN CHAR_LENGTH(cc.alias) THEN CONCAT_WS(":", cc.id, cc.alias) ELSE cc.id END as catslug'.
			' FROM #__content AS a' .
			' LEFT JOIN #__content_frontpage AS f ON f.content_id = a.id' .
			' INNER JOIN #__categories AS cc ON cc.id = a.catid' .
			' INNER JOIN #__sections AS s ON s.id = a.sectionid' .
			' WHERE ( a.state = 1 AND s.id > 0 )' .
			' AND ( a.publish_up = '.$db->Quote($nullDate).' OR a.publish_up <= '.$db->Quote($now).' )' .
			' AND ( a.publish_down = '.$db->Quote($nullDate).' OR a.publish_down >= '.$db->Quote($now).' )'.
			($access ? ' AND a.access <= ' .(int) $aid. ' AND cc.access <= ' .(int) $aid. ' AND s.access <= ' .(int) $aid : '').
			($catid ? $catCondition : '').
			($secid ? $secCondition : '').
			($show_front == '0' ? ' AND f.content_id IS NULL' : '').
			' AND s.published = 1' .
			' AND cc.published = 1' .
			' ORDER BY a.hits DESC';
		$db->setQuery($query, 0, $count);
		$rows = $db->loadObjectList();

		$i		= 0;
		$lists	= array();
		foreach ( $rows as $row )
		{
			$introtext = $row->introtext;
			preg_match_all('/<img[^>]*>/',$introtext,$images);
			$introtext = preg_replace( '/<img[^>]*>/', '', $introtext );
			if(@$images[0][0] != ""){
				$images[0][0] = preg_replace('/width=\"(.*?)\"/', '', $images[0][0]);
				$images[0][0] = preg_replace('/width=\'(.*?)\'/', '', $images[0][0]);
				$images[0][0] = preg_replace('/height=\"(.*?)\"/', '', $images[0][0]);
				$images[0][0] = preg_replace('/height=\'(.*?)\'/', '', $images[0][0]);
			}
			$lists[$i]->thumb = @$images[0][0];
			$lists[$i]->introtext = modVEMostReadHelper::truncString(modVEMostReadHelper::cleanHtml($row->introtext),$params->get('number_intro', 50));
			if($row->access <= $aid)
			{
				$lists[$i]->link = JRoute::_(ContentHelperRoute::getArticleRoute($row->slug, $row->catslug, $row->sectionid));
			} else {
				$lists[$i]->link = JRoute::_('index.php?option=com_user&view=login');
			}
			$lists[$i]->text = modVEMostReadHelper::truncString(htmlspecialchars( $row->title ),30);
			$lists[$i]->created = JHTML::_('date', $row->created, JText::_('DATE_FORMAT_LC2'));
			$i++;
		}

		return $lists;
	}
	function truncString($str = "", $len = 150, $more = 'true') {
			if ($str == "") return $str;
			if (is_array($str)) return $str;
			$str = trim($str);
			// if it's les than the size given, then return it
			if (strlen($str) <= $len) return $str;
			// else get that size of text
			$str = substr($str, 0, $len);
			// backtrack to the end of a word
			if ($str != "") {
			  // check to see if there are any spaces left
			  if (!substr_count($str , " ")) {
				if ($more == 'true') $str .= "...";
				return $str;
			  }
			  // backtrack
			  while(strlen($str) && ($str[strlen($str)-1] != " ")) {
				$str = substr($str, 0, -1);
			  }
			  $str = substr($str, 0, -1);
			  if ($more == 'true') $str .= "...";
			  if ($more != 'true' and $more != 'false') $str .= $more;
			}
			return $str;
  }
  function cleanHtml($clean_it) {

	$clean_it = preg_replace('/\r/', ' ', $clean_it);
	$clean_it = preg_replace('/\t/', ' ', $clean_it);
	$clean_it = preg_replace('/\n/', ' ', $clean_it);

	$clean_it= nl2br($clean_it);

// update breaks with a space for text displays in all listings with descriptions
	while (strstr($clean_it, '<br>')) $clean_it = str_replace('<br>', ' ', $clean_it);
	while (strstr($clean_it, '<br />')) $clean_it = str_replace('<br />', ' ', $clean_it);
	while (strstr($clean_it, '<br/>')) $clean_it = str_replace('<br/>', ' ', $clean_it);
	while (strstr($clean_it, '<p>')) $clean_it = str_replace('<p>', ' ', $clean_it);
	while (strstr($clean_it, '</p>')) $clean_it = str_replace('</p>', ' ', $clean_it);

// temporary fix more for reviews than anything else
	while (strstr($clean_it, '<span class="smallText">')) $clean_it = str_replace('<span class="smallText">', ' ', $clean_it);
	while (strstr($clean_it, '</span>')) $clean_it = str_replace('</span>', ' ', $clean_it);

	while (strstr($clean_it, '  ')) $clean_it = str_replace('  ', ' ', $clean_it);

// remove other html code to prevent problems on display of text
	$clean_it = strip_tags($clean_it);
	return $clean_it;
  }
}
