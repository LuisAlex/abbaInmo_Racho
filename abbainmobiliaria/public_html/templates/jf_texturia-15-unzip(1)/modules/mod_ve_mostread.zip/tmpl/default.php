<?php
/*------------------------------------------------------------------------
# mod_ve_mostread - Most Read Content 2
# ------------------------------------------------------------------------
# author    Vsmart Extensions
# copyright Copyright (C) 2010 www.vsmart-extensions.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://www.vsmart-extensions.com
# Technical Support:  Forum - http://www.vsmart-extensions.com
-------------------------------------------------------------------------*/
// no direct access
defined('_JEXEC') or die('Restricted access');
$document = JFactory::getDocument();
$css= ".ve-mostread li{
	list-style:none;
	margin-bottom:15px;
}
.ve-mostread{
	padding:0px;
	margin:20px 10px 0px 10px !important;
}
.ve-thumb{
	float:left;
	background:url(modules/mod_ve_mostread/tmpl/images/background.png) no-repeat;
	margin-right:5px;
	width:79px;
	height:52px;
	overflow:hidden;
	padding-left:4px;
	padding-top:3px;
}
.ve-mostread .ve-thumb a{
	display:block !important;
	width:75px;
	height:48px !important;
	overflow:hidden;
}
.ve-mostread img{
	width:75px;
	border:0px;
}
a.ve-link,a.ve-link:visited{
	color:#fff;
	font-size:12px;
}
a.ve-link:hover{
	color:#303030 !important;
}
.ve-mostread li a{
	font-weight:bold !important;
	background:none !important;
	display:inline !important;
	height:auto !important;
	line-height:120% !important;
}";
	$document->addStyleDeclaration($css);
?>
<ul class="ve-mostread">
<?php foreach ($list as $item) :  ?>
	<li>
		<div class="ve-thumb">
			<a href="<?php echo $item->link; ?>">
				<?php if($item->thumb != ""){ ?>
					<?php echo $item->thumb; ?>
				<?php }else{ ?>
					<img src="<?php echo JURI::base(); ?>modules/mod_ve_mostread/tmpl/images/no_image.jpg" alt=""/>
				<?php } ?>
			</a>
		</div>
		<a href="<?php echo $item->link; ?>" class="ve-link" >
			<?php echo $item->text; ?></a><br />
			<?php //echo $item->introtext; ?>
		<div style="clear:both;"></div>
	</li>
<?php endforeach; ?>
</ul>
