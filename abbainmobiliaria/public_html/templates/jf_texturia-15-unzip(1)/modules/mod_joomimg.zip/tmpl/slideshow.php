<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Module/JoomImages/trunk/tmpl/slideshow.php $
// $Id: slideshow.php 2599 2010-11-28 17:11:17Z aha $
/**
* Module JoomImages 1.5
* by JoomGallery::Project Team
* @package JoomGallery
* @Copyright JoomGallery team
* @ All rights reserved
* @ Joomla Open Source is Free Stuff
* @ Released under GnuGPL License.
**/

// no direct access
defined('_JEXEC') or die('Restricted access');
$imageType  = $joomimgObj->getConfig('type');

$doc =JURI::base( true );
switch ($imageType)
{
  case 'img':
    $imagePath=$doc."/".$joomimgObj->getJConfig('jg_pathimages');
    break;
  case 'orig':
    $imagePath=$doc."/".$joomimgObj->getJConfig('jg_pathoriginalimages');
    break;
  default:
    $imagePath=$doc."/".$joomimgObj->getJConfig('jg_paththumbs');
    break;
}

$showLink         = $joomimgObj->getConfig('piclinkslideshow');
$showCaption      = $joomimgObj->getConfig('showCaption');
$showTitleCaption = $joomimgObj->getConfig('showTitleCaption');
$heightCaption    = $joomimgObj->getConfig('heightCaption');
$width            = $joomimgObj->getConfig('width');
$height           = $joomimgObj->getConfig('height');
$imageDuration    = $joomimgObj->getConfig('imageDuration');
$transDuration    = $joomimgObj->getConfig('transDuration');
$transType        = $joomimgObj->getConfig('transType');
$transition       = $joomimgObj->getConfig('transition');
$pan              = $joomimgObj->getConfig('pan');
$zoom             = $joomimgObj->getConfig('zoom');
$loadingDiv       = $joomimgObj->getConfig('loadingDiv');
$imageResize      = $joomimgObj->getConfig('imageResize');
$titleSize        = $joomimgObj->getConfig('titleSize');
$titleColor       = $joomimgObj->getConfig('titleColor');
$descSize         = $joomimgObj->getConfig('descSize');
$descColor        = $joomimgObj->getConfig('descColor');

$strip_arr= array("'","\r\n", "\n", "\r");
?>
<div class="modjoomimg">
  <div id="slidewrap">
    <div id="slideshow<?php echo $moduleid;?>">
    <script type="text/javascript" src="<?php echo $doc ?>/modules/mod_joomimg/assets/jquery.jcarousel.min.js"></script>
    <script type="text/javascript">
		jQuery(document).ready(function() {
			jQuery('.carousel').jcarousel();
		});
	</script>
    	<ul class="carousel">  
        <?php
			$countobjects=count($imgobjects);
				foreach ($imgobjects as $img)
			{
				  switch($showLink)
				  {
					case 1: //Category
					$url = $joomimgObj->route('index.php?view=category&catid='.$img->catid);
					break;
					case 2: //Detail
					$url = $joomimgObj->route('index.php?view=detail&id='.$img->id);
					break;
					default:
					$url = '';
					break;
				  }
				  echo '<li><a href="'.$url.'"><img src="'.$imagePath.$img->catpath."/".$img->imgthumbname.'" /></a></li>';
				}
			?>
        </ul>
    </div>
  </div>
</div>