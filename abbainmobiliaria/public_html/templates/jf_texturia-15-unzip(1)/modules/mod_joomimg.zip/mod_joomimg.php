<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-1.5/Module/JoomImages/trunk/mod_joomimg.php $
// $Id: mod_joomimg.php 3005 2011-04-27 04:52:18Z aha $
/**
* Module JoomImages 1.5
* by JoomGallery::Project Team
* based on module for PonyGallery ML by Benjamin Malte Meier 10/08/2007"
* @package JoomGallery
* @Copyright JoomGallery team and b2m
* @ All rights reserved
* @ Joomla Open Source is Free Stuff
* @ Released under GnuGPL License.
**/

// No direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.helper');
if (!JComponentHelper::isEnabled('com_joomgallery', true))
{
  echo JText::_('JIJGNOTINSTALLED');
  return;
}

// Get the interface
require_once(JPATH_ROOT.DS.'components'.DS.'com_joomgallery'.DS.'interface.php');

// Include the helper class only once
require_once (dirname(__FILE__).DS.'helper.php');

// Id of actual module instance
$moduleid = $module->id;

// Create helper object
$joomimgObj = new modJoomImagesHelper();

if($joomimgObj->getGalleryVersion() < "1.5.7")
{
  echo JText::sprintf('JIJOOMGALLERY_NOT_UPTODATE', '1.5.7');
  return;
}
jimport('joomla.filesystem.file');

// Fill the interface object and get the images
$imgobjects = $joomimgObj->fillObject($params,$moduleid);

// Slideshow or default view
if($joomimgObj->getConfig('slideshowthis') == 1)
{
  $path = JModuleHelper::getLayoutPath('mod_joomimg', 'slideshow');
}
else
{
  $path = JModuleHelper::getLayoutPath('mod_joomimg', 'default');
}
if (JFile::exists($path))
{
  require($path);
}
?>