<?php
/*------------------------------------------------------------------------
# mod_simplecontact - Simple Contact
# ------------------------------------------------------------------------
# author    Vsmart Extensions
# copyright Copyright (C) 2010 www.vsmart-extensions.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://www.vsmart-extensions.com
# Technical Support:  Forum - http://www.vsmart-extensions.com
-------------------------------------------------------------------------*/

defined('_JEXEC') or die('Restricted access');
require_once (dirname(__FILE__).DS.'helper.php');

JHTML::_('behavior.formvalidation');

$submit_text = $params->get('submit_text', 'Send us a mail');
$name_text = $params->get('name_text', 'Your Name');
$email_text = $params->get('email_text', 'Your Email');
$message_text = $params->get('message_text', 'Your Message');

$moduleclass_sfx = $params->get('moduleclass_sfx', null);
$contact_task = JRequest::getVar('contact_task', null, 'POST');
$contact_task = JRequest::getVar('contact_task', null, 'POST');

if ($contact_task == 'send') {
    $sendMessage = modSimpleContactHelper::sendEmail($params);
}

?>
<script language="javascript">
	function contactValidate(f)
	{
		if (document.formvalidator.isValid(f)) {
			f.check.value='<?php echo JUtility::getToken(); ?>';
			return true; 
		} else {
			alert('Please enter your contact details. Please try again.');
		}
		return false;
	}
	function clearText(field)
	{
		if (field.defaultValue == field.value)
		{
			field.value = '';
		}
	}

</script>
<div id="contactForm<?php echo $moduleclass_sfx; ?>">
	<p><?php echo $sendMessage; ?></p>
	<form id="contactForm" method="post" class="form-validate" onSubmit="return contactValidate(this);" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
		<div class="contact-left">
			<input name="name" type="text" class="contactInput" value="<?php echo $name_text; ?>" onFocus="clearText(this)" />
			<input name="email" type="text" class="contactInput required validate-email" value="<?php echo $email_text; ?>" onFocus="clearText(this)" />
		</div>
		<div class="contact-right">
			<textarea name="text" class="contactTextarea"><?php echo $message_text; ?></textarea>
		</div>
		<div class="clr"></div>
	   <input type="submit" value="<?php echo $submit_text; ?>" class="contactButton" />
       <input type="hidden" name="contact_task" value="send" />
	   <input type="hidden" name="check" value="post" />
  </form>
</div>
