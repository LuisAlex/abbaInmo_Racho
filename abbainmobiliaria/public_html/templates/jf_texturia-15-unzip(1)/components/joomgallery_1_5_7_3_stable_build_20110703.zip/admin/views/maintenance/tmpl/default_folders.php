<?php

defined('_JEXEC') or die('Direct Access to this location is not allowed.');
      if($this->current_tab != 'folders'): ?>
<div>
  <ul class="jg-message">
    <li><?php echo JText::_('JGA_MAIMAN_MSG_REFRESH_NECESSARY'); ?></li>
  </ul>
  <script type="text/javascript">
    $('cpanel-panel-joom-maintenance-file-folders').addEvent('click', function(){
      document.location.href="index.php?option=<?php echo _JOOM_OPTION; ?>&controller=maintenance&tab=folders";
    });
  </script>
</div>
<?php else: ?>
<form action="index.php" method="post" name="adminForm">
  <table cellpadding="4" cellspacing="0" border="0" width="100%">
    <tr>
      <td>
        <fieldset class="jg_mntchoices">
          <legend><?php echo JText::_('JGA_MAIMAN_BATCH_JOBS'); ?></legend>
          <?php echo $this->lists['folder_jobs']; ?>
          <p id="batchjobs"></p>
          <input type="submit" value="<?php echo JText::_('JGA_MAIMAN_APPLY'); ?>" onclick="if(document.adminForm.job.value == ''){return false;}else{submitbutton(document.adminForm.job.value);}"/>
        </fieldset>
      </td>
      <td width="100%"></td>
      <td><?php echo JText::_('JGA_COMMON_SEARCH'); ?><br />
        <input type="text" name="folder_search" value="<?php echo $this->folder_searchtext; ?>" class="inputbox" onchange="document.adminForm.submit();" />
      </td>
      <td>
        <?php echo JText::_('JGA_MAIMAN_OF_ORDERBY_FOLDERNAME'); ?><br />
        <?php echo $this->lists['folder_ordering']; ?>
      </td>
      <td>
        <?php echo JText::_('JGA_MAIMAN_FILTER_BY_PROPOSAL'); ?><br />
        <?php echo $this->lists['folder_proposal']; ?>
      </td>
      <!--<td>
        <?php echo JText::_('JGA_COMMON_FILTER_BY_TYPE'); ?><br />
        <?php echo $this->lists['folder_filter']; ?>
      </td>-->
    </tr>
  </table>
  <table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminlist">
    <tr>
      <th width="5">
        <?php echo JText::_('Num'); ?>
      </th>
      <th width="20">
        <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo $this->checked ? count($this->items) : 0; ?>);" />
      </th>
      <th class="title">
        <?php echo JText::_('JGA_MAIMAN_OF_FULLPATH'); ?>
      </th>
      <!--<th width="10%" align="center">
        <?php echo JText::_('JGA_COMMON_TYPE'); ?>
      </th>-->
      <th width="10%" align="center">
        <?php echo JText::_('JGA_MAIMAN_SUGGESTION'); ?>
      </th>
      <th width="5" align="left">
        <?php echo JText::_('ID'); ?>
      </th>
    </tr>
<?php if($this->checked):
        if($n = count($this->items)):
          $k = 0;
          for($i = 0; $i < $n; $i++):
            $row = &$this->items[$i];
            $checked    = JHTML::_('grid.id', $i, $row->id); ?>
    <tr class="row<?php echo $k; ?>">
      <td>
        <?php echo $this->pagination->getRowOffset($i); ?>
      </td>
      <td>
        <?php echo $checked; ?>
      </td>
      <td>
        <?php echo /*$row->type == 'unknown' ? $this->warning(JText::_('JGA_MAIMAN_UNKNOWN_FILE_TYPE'), JText::_('JGA_MAIMAN_UNKNOWN_FILE_TYPE_LONG')) : ''; ?>&nbsp;<?php echo */$row->fullpath; ?>
      </td>
      <!--<td align="center">
        <?php /*if($row->type != 'unknown'):*/
                echo JText::_('JGA_TYPE_'.strtoupper($row->type));
              /*else:
                #jimport('joomla.filesystem.file');
                echo JText::sprintf('JGA_MAIMAN_TYPE_UNKNOWN_VAL'/*, JFile::getExt($row->fullpath));
              endif;*/ ?>
      </td>-->
      <td align="center">
<?php       if($row->refid): ?>
        <span title="<?php echo JText::_('JGA_MAIMAN_OF_SHOW_CATEGORY_DETAILS'); ?>" class="hasTip">
          <a href="index.php?option=<?php echo _JOOM_OPTION; ?>&amp;controller=categories&amp;task=edit&amp;cid=<?php echo $row->refid; ?>">
            <?php echo $row->title; ?>
          </a>
        </span>
        <?php echo $this->correct('addorphanedfolder', $row->id, JText::_('JGA_MAIMAN_OF_ADD_ORPHANED_FOLDER_TO_CATEGORY'), false, '&amp;tab=folders'); ?>
<?php       else: ?>
        <?php echo $this->cross('JGA_MAIMAN_NO_PROPOSAL'); ?>
        <?php echo $this->correct('deleteorphanedfolder', 0, JText::_('JGA_MAIMAN_OF_DELETE_THIS_ORPHANED_FOLDER'), 'javascript:listItemTask(\'cb'.$i.'\', \'deleteorphanedfolder\');', '&amp;tab=folders'); ?>
<?php       endif; ?>
      </td>
      <td>
        <?php echo $row->id; ?>
      </td>
    </tr>
<?php       $k = 1 - $k;
          endfor; ?>
    <tr>
      <td colspan="6">
        <?php echo $this->pagination->getListFooter(); ?>
      </td>
    </tr>
<?php   else: ?>
    <tr>
      <td colspan="6">
        <div class="jg_mntnoorphans">
          <p>
            <span class="jg_mntnoorphanstxt">
              <?php echo JText::_('JGA_MAIMAN_OF_MSG_NO_ORPHANED_FOLDERS_FOUND'); ?>
            </span>
          </p>
        </div>
      </td>
    </tr>
<?php   endif; ?>
    <tr>
      <td colspan="6">
        <div class="jg_mntcheckagain">
          <p>
            <input type="submit" name="check" value="<?php echo JText::_('JGA_MAIMAN_CHECK_AGAIN'); ?>" onclick="document.adminForm.task.value = 'check';" />
          </p>
        </div>
      </td>
    </tr>
<?php else: ?>
    <tr>
      <td colspan="6">
        <div class="jg_mntcheckagain">
          <p>
            <span class="jg_mntchecktext">
              <?php echo JText::_('JGA_MAIMAN_PLEASE_CHECK'); ?>
            </span>
          </p>
          <input type="submit" name="check" value="<?php echo JText::_('JGA_MAIMAN_CHECK'); ?>" onclick="document.adminForm.task.value = 'check';" />
          <p>
            <span class="jg_mntchecknote">
              <?php echo JText::_('JGA_MAIMAN_CHECK_NOTE'); ?>
            </span>
          </p>
        </div>
      </td>
    </tr>
<?php endif; ?>
  </table>
  <div>
    <input type="hidden" name="option" value="<?php echo _JOOM_OPTION; ?>" />
    <input type="hidden" name="controller" value="maintenance" />
    <input type="hidden" name="task" value="" />
    <input type="hidden" name="tab" value="folders" />
    <input type="hidden" name="boxchecked" value="0" />
  </div>
</form>
<?php endif;
