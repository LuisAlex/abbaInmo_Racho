<?php defined('_JEXEC') or die('Direct Access to this location is not allowed.'); ?>
<?php if($this->_config->get('jg_anchors')): ?>
  <a name="category"></a>
<?php endif; ?>
<?php if($this->_config->get('jg_showpiccount')): ?>
  <div class="jg_catcountimg">
<?php   if($this->totalimages == 1): ?>
    <?php echo JText::_('JGS_THERE_IS_ONE_PICTURE_IN_CATEGORY'); ?>
<?php   endif;
        if($this->totalimages > 1): ?>
    <?php echo JText::sprintf('JGS_CATEGORY_THERE_ARE_IMAGES_IN_CATEGORY', $this->totalimages); ?>
<?php   endif; ?>
  </div>
<?php endif; ?>
  <div class="pagenav jg_paginationimg">
<?php
      if($this->totalpages > 1):
        if($this->page - 1 > 0): ?>
    <a class="pagenav_prev jg_pagination_prev" href="<?php echo JRoute::_('index.php?view=category&catid='.$this->category->cid.'&page='.($this->page - 1).'&catpage='.$this->catpage.$this->order_url).JHTML::_('joomgallery.anchor', 'category'); ?>">
      <?php echo 'back'; ?></a>&nbsp;
<?php   endif;
        if($this->page - 1 <= 0): ?>
    <span class="pagenav_prev jg_pagination_prev">
    	<?php echo 'back'; ?>&nbsp;
    </span>
<?php   endif; ?>
      <?php echo JHTML::_('joomgallery.pagination', 'index.php?view=category&catid='.$this->category->cid.'&page=%u&catpage='.$this->catpage.$this->order_url, $this->totalpages, $this->page, 'category'); ?>
<?php   if($this->page + 1 <= $this->totalpages): ?>
    &nbsp;
    <a class="pagenav_next jg_pagination_next" href="<?php echo JRoute::_('index.php?view=category&catid='.$this->category->cid.'&page='.($this->page + 1).'&catpage='.$this->catpage.$this->order_url).JHTML::_('joomgallery.anchor', 'category'); ?>">
      <?php echo 'next'; ?></a>
<?php   endif;
        if($this->page + 1 > $this->totalpages): ?>
    <span class="pagenav_next jg_pagination_next">
      &nbsp;<?php echo 'next'; ?>
    </span>
<?php   endif;
      endif; ?>
  </div>
